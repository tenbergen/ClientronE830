 A filter driver for removing the RMB has been made by Hitachi for their Microdrives (Compatct Flash cards with a mini harddrive):
xpfildrvr1224_320.zip
It is 32 bits only, so it will not work on x64 editions of Windows.

By modifying the included INF file the filter driver can be used with any other 'removable' drive.
For the device detection there are the lines in section [cfadisk_device]:

[cfadisk_device]
%Microdrive_devdesc% = cfadisk_install,IDE\DiskIBM-DSCM-11000__________________________SC2IC801

"IDE\DiskIBM-DSCM-11000__________________________SC2IC801" is the device ID of one of the supported Microdrives.
In analogy to these lines we add one line for each 'removable' USB drive we want to turn into a USB hard drive. The ID is found in the Windows device management: Expand 'Disk drives', right click your USB drive, select Properties. On the tab "Details" under XP the item "Device instance ID" is already selected. Click on the ID in the List and press Ctrl+C, this copies the ID into the Windows Clipboard and can be pasted somewhere else with Ctrl+V.
XP up to SP1 shows the tab "Details" only when the environment variable DEVMGR_SHOW_DETAILS=1 is set:
DevMgr_Show_1.reg download and doubleclick the file, then relogon to take effect.

Sample:
USBSTOR\DISK&VEN_LEXAR&PROD_JUMPDRIVE&REV_1.30\K326441127040&0
We need the fat part:

[cfadisk_device]
%Microdrive_devdesc% = cfadisk_install,USBSTOR\DISK&VEN_LEXAR&PROD_JUMPDRIVE&REV_1.30

Or much more simple the universal way for any USB disk:
%Microdrive_devdesc% = cfadisk_install,USBSTOR\GenDisk

In the last line of the INF file we change "Hitachi Microdrive" into something nice as "RemovableToFixed".

In the device manager again right-click the USB drive, "Update driver...", then "No, not this time" -> Next -> "Install from a list or..." -> Next -> "Don't search." -> Next -> "Have Disk" -> browse to the INF file here. Now "RemovableToFixed" should be in the list -> Next -> Confirm the two warnings -> Finish.
Now the drive is redetected, actually as USB hard drive. The drive can be partitioned, the policy "Optimize for performance" indeed activates a write cache on FAT formatted drives and Windows will create the beloved folder "System Volume Information"...
My tries to automat the installtion by means of Microsoft DEVCON did not succeed.

The filter driver can be removed by deleting the drive in the Windows Device Manager. After reattaching the drive its drivers are installed again, but not the filter driver. 